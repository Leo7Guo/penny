const storage = typeof browser !== 'undefined' ? browser.storage.local : chrome.storage.local;

document.addEventListener('DOMContentLoaded', function () {
    const urlInputs = document.getElementById('urlInputs');
    const btnEdit = document.getElementById('editBtn');
    const btnAdd = document.getElementById('addBtn');
    const btnDel = document.getElementById('delBtn');
    let isEditable = false;

    loadUrlFavs();

    function loadUrlFavs() {
        storage.get('urlFavs', function (result) {
            const urlFavs = result?.urlFavs || {};
            console.log(urlFavs);
            Object.keys(urlFavs).forEach(url => {
                const iconSrc = urlFavs[url].icon || getFaviconUrl(url);
                addNewInput(url, iconSrc);
            });
        });
    }

    btnEdit.addEventListener('click', function () {
        if (isEditable) {
            saveUrlFavs();
            window.location.reload();
        }
        isEditable = !isEditable;
        toggleEdit();
    });

    btnAdd.addEventListener('click', function () {
        addNewInput();
        isEditable = true;
        toggleEdit();
    });

    btnDel.addEventListener('click', function () {
        document.querySelectorAll('.deleteCheckbox:checked').forEach(checkbox => {
            checkbox.parentNode.remove();
        });
        updateLabels();
    });

    function addNewInput(initialUrl = '', initialFavicon = '') {
        const newInputDiv = document.createElement('div');
        const icon = createIcon(initialFavicon);
        const newInput = createUrlInput(initialUrl);
        const checkbox = createCheckbox();
        const moveupBtn = createMoveUpButton(newInputDiv);

        newInputDiv.appendChild(createLabel());
        newInputDiv.appendChild(icon);
        newInputDiv.appendChild(newInput);
        newInputDiv.appendChild(checkbox);
        newInputDiv.appendChild(moveupBtn);
        urlInputs.appendChild(newInputDiv);
        newInput.addEventListener('blur', function () {
            icon.src = getFaviconUrl(newInput.value);
            // saveUrlFavs();
        });

        moveupBtnClickHandler(moveupBtn, newInputDiv);
        newInput.addEventListener('input', saveUrlFavs);
    }

    function createIcon(initialFavicon) {
        const icon = document.createElement('img');
        icon.className = 'urlIcon';
        icon.alt = ' ';
        icon.src = initialFavicon;

        icon.addEventListener('error', () => {
            icon.src = './icons/edit.png';
        });
        return icon;
    }

    function createUrlInput(initialUrl) {
        const newInput = document.createElement('input');
        newInput.className = 'urlInput';
        newInput.type = 'text';
        newInput.placeholder = 'Enter URL';
        newInput.value = initialUrl;
        newInput.disabled = true;
        return newInput;
    }

    function createCheckbox() {
        const checkbox = document.createElement('input');
        checkbox.type = 'checkbox';
        checkbox.className = 'deleteCheckbox';
        checkbox.disabled = true;
        return checkbox;
    }

    function createMoveUpButton(newInputDiv) {
        const moveupBtn = document.createElement('button');
        moveupBtn.disabled = true;
        moveupBtn.classList.add('moveup-btn');
        moveupBtn.innerHTML = '&#x21E7;';
        return moveupBtn;
    }

    function moveupBtnClickHandler(moveupBtn, selectedDiv) {
        let clickTimer = null;

        moveupBtn.addEventListener('click', function () {
            if (clickTimer) {
                clearTimeout(clickTimer);
                clickTimer = null;
                return;
            }

            clickTimer = setTimeout(() => {
                moveUp(selectedDiv);
                saveUrlFavs();
                clickTimer = null;
            }, 300);
        });

        moveupBtn.addEventListener('dblclick', function () {
            clearTimeout(clickTimer);
            clickTimer = null;
            moveToTop(selectedDiv);
            saveUrlFavs();
        });
    }

    function createLabel() {
        const label = document.createElement('label');
        label.textContent = (urlInputs.childElementCount + 1) + '.';
        return label;
    }

    function moveUp(selectedDiv) {
        const parent = selectedDiv.parentNode;
        if (selectedDiv.previousElementSibling) {
            parent.insertBefore(selectedDiv, selectedDiv.previousElementSibling);
            updateLabels();
        }
    }

    function moveToTop(selectedDiv) {
        const parent = selectedDiv.parentNode;
        parent.insertBefore(selectedDiv, parent.firstChild);
        updateLabels();
    }

    function updateLabels() {
        document.querySelectorAll('#urlInputs > div > label').forEach((label, index) => {
            label.textContent = (index + 1) + '.';
        });
    }

    function isValidUrl(url) {
        const pattern = /^(https?:\/\/)?([\w-]+(\.[\w-]+)+(:\d+)?(\/[\w-./?%&=]*)?)$/;
        return pattern.test(url);
    }

    function updateUrlFavIcon(url, iconSrc) {
        storage.get('urlFavs', function (result) {
            const urlFavs = result?.urlFavs || {};
            if (urlFavs[url]) {
                urlFavs[url].icon = iconSrc;
                saveUrlFavs(urlFavs);
            }
        });
    }

    function saveUrlFavs() {
        const urlFavs = {};
        document.querySelectorAll('.urlInput').forEach(input => {
            const url = input.value.trim();
            if (url && isValidUrl(url)) {
                urlFavs[url] = { icon: input.previousElementSibling.src };
            }
        });

        storage.set({ urlFavs }, function () {
            if (chrome?.runtime.lastError || browser?.runtime.lastError) {
                console.error("保存URL时出错:", chrome?.runtime.lastError || browser?.runtime.lastError);
            }
        });
    }

    function toggleEdit() {
        const inputs = document.querySelectorAll('.urlInput');
        const checkboxes = document.querySelectorAll('.deleteCheckbox');
        const icons = document.querySelectorAll('.urlIcon');
        const moveupBtns = document.querySelectorAll('.moveup-btn');

        const isDisabled = !isEditable;

        inputs.forEach(input => input.disabled = isDisabled);
        checkboxes.forEach(checkbox => checkbox.disabled = isDisabled);
        moveupBtns.forEach(btn => btn.disabled = isDisabled);

        if (isEditable) {
            btnEdit.textContent = 'Save';
            icons.forEach(icon => setIconClickEvent(icon));
        } else {
            btnEdit.textContent = 'Edit';
            icons.forEach(icon => {
                icon.style.cursor = 'default';
                icon.onclick = null;
            });
        }
    }

    function setIconClickEvent(icon) {
        icon.style.cursor = 'pointer';
        const fileInput = document.createElement('input');
        fileInput.type = 'file';
        fileInput.accept = 'image/*';
        fileInput.style.display = 'none';

        fileInput.addEventListener('change', function (event) {
            const file = event.target.files[0];
            if (file) {
                const reader = new FileReader();
                reader.onload = function (e) {
                    icon.src = e.target.result;
                    updateUrlFavIcon(icon.previousElementSibling.value, e.target.result);
                };
                reader.onerror = () => console.error("文件读取出错");
                reader.readAsDataURL(file);
            }
        });

        icon.parentNode.appendChild(fileInput);
        icon.onclick = () => fileInput.click();
    }

    function getFaviconUrl(url) {
        if (!/^https?:\/\//.test(url)) {
            url = 'https://' + url;
        }
        return url + '/favicon.ico';
    }
});
