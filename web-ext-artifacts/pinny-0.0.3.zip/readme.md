Pinny使用iframe嵌入的方式，就像一个固定在页面上的便签窗口，始终保持在当前页面。用户可以方便地管理和快速访问收藏的网址，而无需离开当前窗口。通过点击图标或导航点，用户可以轻松切换不同的页面。

Pinny is a browser extension that uses iframe embedding, functioning like a sticky note pinned to the page, which remains on the current page. It allows users to easily manage and quickly access their bookmarked URLs without leaving the current window. By clicking on icons or navigation dots, users can effortlessly switch between different pages.

